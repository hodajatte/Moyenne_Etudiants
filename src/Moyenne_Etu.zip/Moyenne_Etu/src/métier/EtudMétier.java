package métier;

import dao.daVolatile.EtudDao;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.var;
import modèle.Etudiant;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class EtudMétier {
    EtudDao Etudao;
  public Etudiant Calculer_Moyenne_Etud(Long idEtud) throws Exception{
      var Etu = Etudao.trouverParId(idEtud);
      if (Etu==null)
          throw new Exception("L'id incorrecte ou introuvable!!!!");
       else {
           double note1= Etu.getNote_controle();
           double note2=Etu.getNote_tp();
           double note3=Etu.getNote_Examen();
           int Pourcentage_note_controle=25;
           int Pourcentage_note_tp=25;
           int Pourcentage_note_Examen=50;
           double Moyenne_Etu=note1*Pourcentage_note_controle+note2*Pourcentage_note_tp+note3*Pourcentage_note_Examen;
           if (Moyenne_Etu>=16.0)
               System.out.println("Trés Bien");
           else if (Moyenne_Etu == 14.0) {
              System.out.println("Bien");

           } else if (Moyenne_Etu==10.0) {
               System.out.println("Moyen");
               
           }
           else {
               System.out.println("rattrapage");
           }
      }
      return Etu;
  }


    public void setEtudDao(EtudDao dao) {
    }
}
