package présentation;

import dao.daVolatile.EtudDao;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.var;
import métier.EtudMétier;

import java.util.Scanner;
@Data
@AllArgsConstructor
public class SimulatorEtudApp {
    static IEtudControleur Etudcontroleur;
    static Scanner clavier = new Scanner(System.in);
    private static boolean estUnNombre(String input){
        try
        {
            Integer.parseInt(input);
            return true;
        }
        catch (Exception e){
            return false;
        }
    }

    ////*****Instanciation des différents composants de l'application ******////
    public static void test1(){
        var dao = new EtudDao();
        var métier = new EtudMétier();
        var controleur = new EtudControleur();
        ///******** Injections des dépendances*********///
        métier.setEtudDao(dao);
        controleur.setEtuMétier(métier);
        ///*****Tester******///
        String rep ="";
        do {
            System.out.println("=>[Test 1 ] Calcule de Moyenne <=\n");
            try {
                String input = "";
                while (true){
                    System.out.println("=> Veuillez entrer l'id du crédit:!!!!");
                    input = clavier.nextLine();
                    if(estUnNombre(input)) break;
                    System.err.println("Entréé non valide!!!!");
                }
                long id =Long.parseLong(input);
                controleur.afficher_Moyenne_Etud(id);
            } catch (Exception e) {
                System.err.println(e.getMessage());
            }
            System.out.println("Voulez vous quittez (OUI/NON)? ");
            rep =clavier.nextLine();
        } while (!rep.equalsIgnoreCase("OUI"));
        System.out.println(" Au revoir ^_^ ");
    }
    public static void main(String[] args ) throws Exception {
        test1();

    }




}




